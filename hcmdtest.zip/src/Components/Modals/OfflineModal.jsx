// import React from 'react';
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

// const OfflineModal = ({ showModal, togglePopup, handleStayOffline, ReloadAction }) => {
//     return <Modal isOpen={showModal} toggle={togglePopup} keyboard={false} backdrop="static">
//         <ModalHeader>Server Disconnected!</ModalHeader>
//         <ModalBody>
//             <p className='text-color'>
//                 {`Server is disconnected. Please check internet connection to get real-time experience.`}
//             </p>
//         </ModalBody>
//         <ModalFooter>
//             <Button color="secondary" onClick={ReloadAction}>Reload</Button>
//             <Button color="primary" onClick={handleStayOffline}>Stay Offline</Button>
//         </ModalFooter>
//     </Modal>
// }

// export default OfflineModal;