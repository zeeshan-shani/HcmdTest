
class ButtonClass {
    defaultValue = {
        text: "button",
        name: "button",
        type: "primary"
    }
    onChange(data) {
    }
}

export default ButtonClass;
