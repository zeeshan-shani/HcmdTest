class LabelClass {
    defaultValue = {
        id: "",
        name: "label",
        label: "Label Class",
        value: "text label"
    }
    onChange(data) {
    }
}

export default LabelClass;
