
class SelectClass {
    defaultValue = {
        label: "Select",
        name: "selectField",
        value: [],
        description: "",
        options: [{ label: "option 1", value: "option1" }]
    }
    onChange(data) {
    }
}

export default SelectClass;