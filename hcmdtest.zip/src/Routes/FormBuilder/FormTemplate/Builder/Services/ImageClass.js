class ImageClass {
    defaultValue = {
        name: "Image",
        placeholder: "Type here",
        tooltip: "",
        method: "static",
        imageURL: "",
        defaultValue: "",
        value: "",
        style: { height: 100, width: 100 }
    }
    onChange(data) {
    }
}

export default ImageClass;
