class TextFieldClass {
    defaultValue = {
        label: "Signature",
        name: "signatureField",
        description: "",
        value: ""
    }
    onChange(data) {
    }
}

export default TextFieldClass;
