
class PasswordClass {
    defaultValue = {
        label: "password field"
    }
    onChange(data) {
    }
}

export default PasswordClass;
