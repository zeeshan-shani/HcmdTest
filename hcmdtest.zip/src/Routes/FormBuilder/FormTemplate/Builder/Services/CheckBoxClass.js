
class CheckBoxClass {
    defaultValue = {
        label: "Checkbox",
        name: "checkbox",
        value: "",
        defaultValue: "",
        options: [{ label: "option 1", value: "option1" }]
    }
    onChange(data) {
    }
}

export default CheckBoxClass;
