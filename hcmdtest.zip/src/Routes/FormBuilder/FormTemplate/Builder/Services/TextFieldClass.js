class TextFieldClass {
    defaultValue = {
        label: "Text Input",
        name: "textField",
        placeholder: "Type here",
        description: "",
        tooltip: "",
        prefix: "",
        suffix: "",
        autoComplete: "",
        autoFocus: [],
        isEditable: [],
        defaultValue: "",
        value: ""
    }
    onChange(data) {
    }
}

export default TextFieldClass;
