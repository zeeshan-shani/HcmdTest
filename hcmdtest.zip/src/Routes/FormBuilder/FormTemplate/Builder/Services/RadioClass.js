
class RadioClass {
    defaultValue = {
        label: "Radio Label",
        name: "radio",
        value: "",
        defaultValue: "",
        options: [{ label: "option 1", value: "option1" }]
    }
    onChange(data) {
    }
}

export default RadioClass;
