class DateTimeClass {
    defaultValue = {
        label: "Date Label",
        value: "",
        name: "datefield",
        placeholder: "Enter date",
        isClearable: false,
        timeRequired: false
    }
    onChange(data) {
    }
}

export default DateTimeClass;
