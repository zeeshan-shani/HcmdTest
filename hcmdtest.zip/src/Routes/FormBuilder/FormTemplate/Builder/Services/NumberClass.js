
class NumberClass {
    defaultValue = {
        label: "Number input field"
    }
    onChange(data) {
    }
}

export default NumberClass;
