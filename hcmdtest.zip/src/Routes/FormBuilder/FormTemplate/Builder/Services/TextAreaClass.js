
class TextAreaClass {
    defaultValue = {
        label: "Textarea",
        name: "textareaField",
        placeholder: "Type something here",
        rows: 3,
        description: "",
        prefix: "",
        suffix: "",
        autoComplete: "",
        autoFocus: [],
        isEditable: [],
        defaultValue: "",
        value: ""
    }
    onChange(data) {
    }
}

export default TextAreaClass;
