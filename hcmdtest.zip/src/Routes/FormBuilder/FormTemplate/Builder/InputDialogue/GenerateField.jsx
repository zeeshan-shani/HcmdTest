import React from 'react'

export default function GenerateField({ component }) {
    return (
        <div>GenerateField</div>
    )
}