// import React from 'react'
// import { Link } from 'react-router-dom'

// export const ResetPassword = () => {
//     return (<>
//         <h1 className="font-weight-bold">Password Reset</h1>
//         <p className="text-dark mb-3">Enter your email address to reset password.</p>
//         <form className="mb-3">
//             <div className="form-group">
//                 <label htmlFor="email" className="sr-only">Email Address</label>
//                 <input type="email" className="form-control form-control-md" id="email" placeholder="Enter your email" />
//             </div>
//             <button className="btn btn-lg btn-block btn-primary  text-uppercase font-weight-semibold" type="submit">Send Reset Link</button>
//         </form>
//         <p>Already have an account? <Link className="font-weight-semibold" to="/user/login">Sign in</Link>.</p>
//     </>);
// }
