export const CONST = {
    CHAT_CONTENT: 'chat_content',
    PATIENT_CONTENT: 'patient_content',
    CATEGORY_CONTENT: 'category_content',
}