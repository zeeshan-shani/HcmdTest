# HouseCallMD Communication

- Live on: https://hcmdcommunication.com
- Testing on: https://hcmd-communication.vercel.app
- Referances:
  - Chat theme: https://themeforest.net/item/quicky-html-chat-template/27127279


# HCMD stagging branch
- /main/stagging

# HCMD Dev branch
- /main/stagging/narolaDev
# hcmd-frontend


Branch is live on: 
hcmd-bjj.vercel.app
Deploy new UI to zmm-hcmd.vercel.app.
